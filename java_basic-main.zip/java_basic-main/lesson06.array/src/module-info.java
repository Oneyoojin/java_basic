/**
 * 
 */
/**
 * 
 */
module lesson06.array {
}
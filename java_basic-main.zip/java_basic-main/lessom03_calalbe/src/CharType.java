public class FloatDoubleEx {
	
	public static void main(String[]args)
}
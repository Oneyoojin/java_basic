module lesson16_stream {
}
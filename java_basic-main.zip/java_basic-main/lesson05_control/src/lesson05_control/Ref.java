package lesson05_control;

public class Ref {
	public static void main(String[]args) {
		int [] arr = {1,3,5,7,9};
		int [] arr2 = arr; //
		
		arr[0] = 10;
		System.out.println(arr2[0]);
		arr = null;
		arr2 = null;
		
		int a = 10;
		int b = a;
		
		a = 20;
		System.out.println(b);
		
		System.out.println(022);
		System.out.println(0x22); //16진수로 인식
	}

}

package lesson05_control;

public class text_class {
	public static void main(String[]args) {
	
	int price = 187000;
	int oman = 50000 % price;
	int ilman = 10000 /8;
	int ochun = 5000;
	int ilchun = 1000;
	
	System.out.println("5만원권:"+oman+"장");
	System.out.println("1만원권:"+ilman+"장");
	System.out.println("5천원권:"+ochun+"장");
	System.out.println("1천원권"+ilchun+"장");

	}
	
   }


package lesson05_control;

public class WhileEx_java {
	public static void main(String[]args){
		
		int sum = 0;
		int i = 1;
		
		while (i <= 100) {
			sum+= i;
			i++;
			
		}
		System.out.println("합계:"+sum);
		
	}

}

package lesson05_control;

import java.util.Scanner;

public class max {
	public static void test5() {
		Scanner sc = new Scanner(System.in);
		
		int sum = 0, max = 0, min = 0;
		
		for (sum == )
		
			
		}
		
	}
}

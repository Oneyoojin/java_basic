package lesson05_control;

public class info02_Java {
	public static void main(String[]args) {
	int[]arr = {10, 5, 3, 8 ,4};
	arr = new int[10];
	arr =new int[]{1,2,3};
	System.out.println(arr.length);
	char[]cArr = {'A','B','가','나'};
	
	System.out.println(arr);
	System.out.println(cArr);
	
	}
} 

package lesson06_control;

public class Marine {

		// 한계치가 필요함.
		// 현제 체력이 따로 있어야함.
		
		
		
		// 최대 체력
		static int maxHp = 40;
		// 체력
		static int hp = 40;
		// 공격력
		static int att = 6; // 모두가 같은 데이터를 써야한다. static (기획당시 결정)
		// 방어력
		static int def;
		

}

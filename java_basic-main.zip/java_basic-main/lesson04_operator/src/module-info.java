/**
 * 
 */
/**
 * 
 */
module lesson4_operator {
}
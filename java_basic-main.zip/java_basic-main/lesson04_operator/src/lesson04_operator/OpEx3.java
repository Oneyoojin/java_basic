package lesson04_operator;

public class OpEx3 {
	public static void main(String[] args) {
		int a = 10;
		int b = 10;
		
		System.out.println(++a);
		System.out.println(a++);
		System.out.println(a);
		
//		int c = ++a; // 전위 
//		int d = b++; // 후위
//		
//		System.out.println(a);
//		System.out.println(b);
//		System.out.println(c);
//		System.out.println(d);
//		
//		int i = 0, sum = 0;
//		while(i <= 10) {
//			sum += i++;
//		}
//		System.out.println(sum);
		
		/*       입력    출력
		 * 산술  숫자    숫자 
		 * 비교  숫자    논리
 		 * 논리  논리    논리
 		 * 
 		 * 
 		 * 대소비교
		 */
		boolean bool = 10 > 5;
		if(!bool) {
			
		}
		
	}
}

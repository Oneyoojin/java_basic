package lesson04_operator;

public class OpEx1 {
	public static void main(String[] args) {
		double d = 10 / (double)4;
		System.out.println(d);
		
		int a = -5;
		System.out.println(+a);
		
//		System.out.println(0 / 0);
//		int number1 = 10;
//		System.out.println("number1 = 10 -> " + number1);
//		number1 += 10;
//		System.out.println("number1 += 10 -> " + number1);
//		number1 -= 10;
//		System.out.println("number1 -= 10 -> " + number1);
//		number1 *= 2;
//		System.out.println("number1 *= 2 -> " + number1);
//		number1 /= 2;
//		System.out.println("number1 /= 2 -> " + number1);
//		number1 %= 3;
//		System.out.println("number1 %= 3 -> " + number1);
		
	}
}

package lesson07_oop;

public class Marine {
	// 최대체력
	static int maxHp = 40;
	// 체력
	int hp = 40;
	// 공격력
	static int att = 6; 
	// 방어력
	static int def;
}

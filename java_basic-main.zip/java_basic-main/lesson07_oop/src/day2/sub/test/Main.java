package day2.sub.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import static java.lang.Integer.*;

public class Main {
	// hello.world
	
	// www.naver.com
	// com.naver.www
	java.sql.Date d = new java.sql.Date(System.currentTimeMillis());
	public static void main(String[] args) {
//		day2.Circle circle = new day2.Circle();
//		java.util.Scanner scanner = new java.util.Scanner(System.in);
//		Date date = new Date();
//		Arrays.toString(new int[] {});
//		Integer.parseInt("123");
//		parseInt("455");
//		System.out.println(MAX_VALUE);
		
		Arrays.asList(1,2,3,4,5,6).forEach(System.out::println);
		new Date().getMonth();
	}
//	static int parseInt(String str) {
//		return Integer.parseInt(str);
//	}
}

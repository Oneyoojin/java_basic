package day2;

import test2.Member;

public class ModuleTest {
	public static void main(String[] args) {
		Member member = new Member();
	}
}

/**
 * 
 */
/**
 * 
 */
module lesson07_oop {
	requires java.sql;
	requires test2;
}
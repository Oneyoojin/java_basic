package test;

public class class07 {
	public static void main(String[] args) {
		
		int number = 1234;
		System.out.println(number / 100 * 100);
	}

}

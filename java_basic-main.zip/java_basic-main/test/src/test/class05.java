package test;

public class class05 {
	public static void main(String[] args) {
		int year = 2020;
		boolean lepYear = year % 4 == 0 && year % 100 !=0 || year % 400 == 0;
 	}

}

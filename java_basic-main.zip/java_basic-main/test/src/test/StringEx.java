package test;

public class StringEx {
	
	public static void main(String[] args) {
		
		String name; // 변수 선언
		name = "홍길동"; // 변수 초기화
				
		String name2 = "홍길동";
		String name3 = null;
		String name4 = " ";
		
		System.out.println("name2="+name2);
		System.out.println("name3="+name3);
		System.out.println("name4="+name4);
		
		
	}
}
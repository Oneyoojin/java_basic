package test;

public class OpEx7 {
	
	public static void main(String[]args){

	int score = 80;
	String pass = score >= 60 ? "합격" : "불합격";
	System.out.println(pass);
	
	int num = 73;
	String pass2 = score>= 60 ? "짝수" : "홀수";
	System.out.println(pass2);
	
	
	}
}
	
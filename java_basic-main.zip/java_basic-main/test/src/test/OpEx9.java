package test;

public class OpEx9 {
	
	public static void main (String[]args) {
		
		int a = 5;
		int b = 4;
		int c = 3;
		
		System.out.println(a+b*c);
		
		System.out.println((a+b)*c);
	}
}
/**
 * 
 */
/**
 * 
 */
module lesson06_array {
}
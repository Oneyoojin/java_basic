module lesson15_lambda {
}
module test2 {
	exports test2;
}
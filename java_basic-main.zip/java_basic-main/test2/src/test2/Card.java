package test2;

public class Card {
	// 필드
	
	// 생성자
}

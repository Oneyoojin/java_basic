package test2;

public class Member {
	{
		System.out.println("test2.Member");
	}
}

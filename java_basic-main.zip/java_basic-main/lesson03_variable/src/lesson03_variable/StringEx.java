package lesson03_variable;

public class StringEx {
	public static void main(String[] args) {
		String name;
		name = "홍길동";
		String name2 = "홍길동";
		String name3 = null;
		String name4 = "";
		
		System.out.println("name2:"+name2);
		System.out.println("name3:"+name3);
		System.out.println("name4:"+name4);
		
		int num = 10;
		// "10"
		System.out.println(num + "");
	}
}

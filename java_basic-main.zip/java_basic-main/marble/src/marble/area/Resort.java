package marble.area;

public class Resort extends SaleLocal{
	public static final int BUILD_COST = 10;
	public static final int FEE = 8;
	public static final int SALE_PRICE = 5;
	public Resort(int colorIdx, String name, int idx) {
		super(colorIdx, name, idx);
	}
}

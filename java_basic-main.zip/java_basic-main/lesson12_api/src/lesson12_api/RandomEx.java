package lesson12_api;

import java.util.Random;

public class RandomEx {
	public static void main(String[] args) {
		Random random = new Random();
		for(int i = 0 ; i < 20 ; i++) {
//			System.out.println(random.nextInt(6)+1);;
			System.out.println(random.nextInt());
		}
	}
}

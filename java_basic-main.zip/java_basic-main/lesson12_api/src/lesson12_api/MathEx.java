package lesson12_api;

public class MathEx {
	public static void main(String[] args) {
		System.out.println(Math.E);
		System.out.println(Math.PI);
		
		System.out.println(Math.abs(5));
		System.out.println(Math.abs(-5));
		
		System.out.println(Math.floor(3.141592));
		System.out.println(Math.ceil(3.141592));
		System.out.println(Math.round(3.141592));
	}
}

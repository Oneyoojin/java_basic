package mart;

public class Computer extends Product{
	public Computer() {
		setName("컴퓨터");
		setPrice(200);
	}
}

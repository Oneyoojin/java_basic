package mart;

public class AirCon extends Product{
	public AirCon() {
		setName("에어콘");
		setPrice(300);
	}
}

package mart;

public class Tv extends Product{
	public Tv() {
		setName("TV");
		setPrice(100);
	}
}

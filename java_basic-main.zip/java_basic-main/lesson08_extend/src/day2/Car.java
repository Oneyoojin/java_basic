package day2;

public class Car {
	String color;
	String name;
	void go() {
		System.out.println("전진");
	}
	void back() {
		System.out.println("후진");
	}
}

package day2;

public class TaxiMain {
	public static void main(String[] args) {
		Object o = new String("abcd");
		new Taxi().go();
	}
}

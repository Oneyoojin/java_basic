package day2.ex2;

public class Child extends Parent {
	String name = "자식";
	
	void run() {
		System.out.println("자식이 달린다");
	}
	
	void eat() {
		System.out.println("자식이 먹는다");
	}
}

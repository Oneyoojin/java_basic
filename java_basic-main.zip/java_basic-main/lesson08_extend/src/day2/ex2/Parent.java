package day2.ex2;

public class Parent {
	String name = "부모";
	
	void walk() {
		System.out.println("부모가 걷는다");
	}
	
	void run() {
		System.out.println("부모가 달린다");
	}
}

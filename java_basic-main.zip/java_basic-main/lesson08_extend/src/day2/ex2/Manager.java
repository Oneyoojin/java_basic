package day2.ex2;

public abstract class Manager extends Employee{
	public Manager(String name) {
		super(name);
	}
}

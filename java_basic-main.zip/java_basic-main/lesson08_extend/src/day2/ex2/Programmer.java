package day2.ex2;

public class Programmer extends Employee{
	public Programmer(String name) {
		super(name);
	}
	
	void work() {
		System.out.println("코딩을 합니다");
	}
}

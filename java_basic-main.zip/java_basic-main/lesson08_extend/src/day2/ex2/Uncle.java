package day2.ex2;

public class Uncle {
	void walk() {
		System.out.println("삼촌이 걷는다");
	}
}

package day2.ex2;

public class Designer extends Employee{
	public Designer(String name) {
		super(name);
	}
	
	void work() {
		System.out.println("디자인을 합니다");
	}
}

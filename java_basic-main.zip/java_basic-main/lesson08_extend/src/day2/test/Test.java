package day2.test;

public class Test {
	public static void main(String[] args) {
//		day2.A a = new A();
//		a.m();
	}
}

package day2;

public class Taxi extends Car{
	void go(String str) {
		System.out.println("미터기를 켜고 전진");
	}
}

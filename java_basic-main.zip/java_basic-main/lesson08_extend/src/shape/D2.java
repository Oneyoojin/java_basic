package shape;

public interface D2 {
	double length();
}

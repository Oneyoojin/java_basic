package shape;

public interface D3 {
	double volume();
}

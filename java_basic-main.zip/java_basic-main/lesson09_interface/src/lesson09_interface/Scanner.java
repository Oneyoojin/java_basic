package lesson09_interface;

public interface Scanner {
	void scan();
}

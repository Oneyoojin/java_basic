package lesson09_interface.starcraft;

public abstract class AirUnit extends Unit{
	
}

package lesson09_interface.starcraft;

public abstract class Unit {
	int hp;
	String name;
}

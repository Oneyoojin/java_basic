package lesson09_interface.starcraft;

public interface FInter {
	String myMethod(String str);
}

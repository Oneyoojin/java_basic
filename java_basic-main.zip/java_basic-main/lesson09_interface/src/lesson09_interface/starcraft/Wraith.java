package lesson09_interface.starcraft;

public class Wraith extends AirUnit implements Repairable{
	
}

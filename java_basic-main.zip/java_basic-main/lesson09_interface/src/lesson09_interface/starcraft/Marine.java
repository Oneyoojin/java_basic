package lesson09_interface.starcraft;

@Deprecated
public class Marine extends GroundUnit{
	
}

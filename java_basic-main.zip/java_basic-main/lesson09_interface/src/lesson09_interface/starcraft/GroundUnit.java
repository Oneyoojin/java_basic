package lesson09_interface.starcraft;

public abstract class GroundUnit extends Unit{

}

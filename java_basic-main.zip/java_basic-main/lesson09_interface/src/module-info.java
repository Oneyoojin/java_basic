module lesson09_interface {
}